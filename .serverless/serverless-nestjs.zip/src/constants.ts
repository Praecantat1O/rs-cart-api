export const JWT_CONFIG = {
  secret: 'secret',
  expiresIn: '12h'
}

export const PG_CONNECTION = 'PG_CONNECTION';

export const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Credentials': '*',
  'Access-Control-Allow-Headers': '*'
};
